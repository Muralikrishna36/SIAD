<?php
require "auth.php";
?>
	<a href='newuserform.php'> Add a new user</a>
	<a href='changepasswordform.php'>change your password</a>
	<a href='logout.php'>click here to logout</a>
