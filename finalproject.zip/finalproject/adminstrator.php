	
<?php
require "auth.php";
require "indexafterlogin.php";
?>
	
	
 	
